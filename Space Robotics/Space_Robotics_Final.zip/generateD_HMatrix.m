function D_H_Matrix = generateD_HMatrix(A1,A2,A3,A4,A5,A6)
%Generates the D-H Matrix for a given set of A matricies. 
    D_H_Matrix = A1*A2*A3*A4*A5*A6;


end

